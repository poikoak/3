﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedListCS
{

    public class Node
    {
        public Node next;
        public Object data;
        //public Node()
        //{
        //    data = null;
        //    next = null;
        //}
        public Node()
        {
            this.data = null;
            next = null;
        }
        public Node(Object data)
        {
            this.data = data;
            next = null;
        }
    }
    public class LinkedList //: IEnumerable, IEnumerator
    {
        private Node head = new Node(null);
      
        int count = 0;
 
        //public LinkedList()
        //{
        //    head.data = null;
        //    head.next = null;
        //    count = 0;

        //}

        public void Print()
        {
            Node current = head;
            while (current != null)
            {
                Console.WriteLine(current.data);
                current = current.next;
            }
        }
        public void Add(Object item)
        {
           
            if (head == null)
            {
                head = new Node(item);


                //head.next = null;
            }
            else
            {
                Node toAdd = new Node(item);


                Node current = head;
                while (current.next != null)
                {
                    
                    current = current.next;
               
                }

                current.next = toAdd;
              
            }
            count++;
        }
        public int Count()
        {
            return count;
        }
        public void Insert(int index, Object item)
        {
            if (count > index)
            {
                // создать новый элемент списка
                Node elem = new Node(item);

                if (index == 0)
                {

                    elem.next = head;


                    head = elem;
                    count++;
                    return;
                }

                Node current = head;
                int n = 0;

                while (current != null)
                {
                 
                    if (index == n+1)
                    {
                        current.data = elem.data;


                        //elem.data = current.data;
                        current = current.next;

                        break;
                    }

                    // "перепрыгнуть" на следующий элемент списка
                    current = current.next;
                    n++;
                }


                // связать новый элемент с элементом index
                elem.next = current;

                count++;
            }
            else throw new Exception("Attemp to insert to empty list!!!");
        }


     


        public static LinkedList operator +(LinkedList l1, LinkedList l2)
        {
            LinkedList res = new LinkedList();
            Node temp = l1.head;
            while ( temp!=null)
            {
                res.Add(temp.data);
                temp = temp.next;

            }
            temp = l2.head;
            while (temp != null)
            {
                res.Add(temp.data);
                temp = temp.next;

            }


   
            return res;
        }

        public static LinkedList operator -(LinkedList item, object obj)
        {
            while (item.head != null && item.head.data.ToString() == obj.ToString())
            {
                item.head = item.head.next;
                item.count--;
            }

            if (item.head == null)
            {
                return item;
            }

            Node current = item.head;
            while (current.next != null)
            {
                if (current.next.data.ToString() == obj.ToString())
                {
                    current.next = current.next.next;
                    item.count--;
                }
                else
                {
                    current = current.next;
                }
            }
            return item;
        }
        public static bool operator !=(LinkedList l, LinkedList l2)
        {
            Node current = l.head;
            Node current2 = l2.head;


            while (current != null)
            {
                // if ( == 0)

                if (Equals(current.data, current2.data))
                {

                    if (current.data == current2.data) return false;
                }
                else return true;
            }

    
            current = current.next;
            current2 = current2.next;
      
            return true;
        }

        public static bool operator ==(LinkedList l, LinkedList l2)
        {

            Node current = l.head;
            Node current2 = l2.head;


            while (current != null)
            {
                // if ( == 0)

                if (Equals(current.data, current2.data))
                {

                    if (current.data == current2.data) return true;
                }
                else return false;
            }

            // "перепрыгнуть" на следующий элемент списка
            current = current.next;
            current2 = current2.next;
            return false;
        }


        //enumerator

        public IEnumerator GetEnumerator()
        {
            Node current = head;
            while (current != null)
            {
                //Console.WriteLine(current.data);
                yield return current.data;
                current = current.next;
            }
           
           
        }


    }
}
