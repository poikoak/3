﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedListCS
{
    class Program
    {
  

        static void Main(string[] args)
        {
            LinkedList list1=new LinkedList();
            LinkedList list2 = new LinkedList();
            //list1.Print();
            list1.Add(10);
            list1.Add(11);
            list1.Add(12);
            list1.Add("ASK");
            //list1.Add(13);
            Console.WriteLine(list1.Count());
            list1.Insert(1, 20);
            Console.WriteLine(list1.Count());
            list1.Print();
            list2.Add(20);
            //foreach (Node node in list1)
            //{
            //    Console.WriteLine((object)node);

            //}




     
            list1.Print();

            if (list1 == list1)
                Console.WriteLine("Equals");
            else Console.WriteLine("NOT equals!!!");

            list1.Print();
            foreach(object node in list1)
               {
                  Console.WriteLine(node);

               }

            Console.WriteLine(list1.Count());

            list1 -= "ASK";
            list1 -= 10;
            Console.WriteLine("AFTER DELETED ASK and 10");
            list1.Print();

            Console.WriteLine("AFTER plus");

            list1 = list1 + list2;
            list1.Print();

        }
    }
}
