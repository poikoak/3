﻿//1.Ставишь таймер выполнять следующие действия раз в n сек. +
//2. Находишь все файлы в директорию и их время изменения, пишешь их в лист или другой мап.+ 
//3. Копируешь все файлы с припиской к имени(в папку backups, в этой же директории?) +
//4.Повторяешь действие 2 и сравниваешь первый мап с новым, если время изменения файла отличается, то пишешь его название в массив. +
//5. Все файлы из массива пакуешь и копируешь заново. +
//6. Перезапись для скопированных бэкапов  в словарике +
//7. Проверка новых файлов и добавление их. +


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Timers;
using System.Threading;
using System.IO.Compression;

namespace Backuper
{
    class Program
    {
        static string dir = @"F:\Users\Admin\Pictures"; static string dir2 = @"F:\Users\Admin\Pictures\BackUps\";
        static void showAllFiles(string path, ref Dictionary<string, DateTime>  dict)
        {
            DirectoryInfo dinfo = new DirectoryInfo(path);
            //Dictionary<string, DateTime> dict = new Dictionary<string, DateTime> { };

            if (dinfo.Exists)
            {
                // Получить массив файлов в текущей папке
                try
                {
                    string[] str = Directory.GetFiles(path, "*");
                    //string[] str = Directory.GetFiles(path, "*", SearchOption.AllDirectories);
                    foreach (string s in str)
                    {
                        //Console.WriteLine(s);
                        DateTime lastModified = System.IO.File.GetLastWriteTime(s);
                       // Console.WriteLine(lastModified);
                        dict.Add(s, lastModified);
                    }


                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            else
            {
                Console.WriteLine("Path is not exists");
            }
        }
     
        static void Compress(string sourceName0, string compressedName0)
        {

            var bytes = File.ReadAllBytes(sourceName0);
            using (FileStream fs = new FileStream(compressedName0, FileMode.CreateNew))
            using (GZipStream zipStream = new GZipStream(fs, CompressionMode.Compress, false))
            {
                zipStream.Write(bytes, 0, bytes.Length);
            }
        }

        static void CopyFromDictionary(string destination, ref Dictionary<string, DateTime> dict, ref Dictionary<string, int> dict2)
        {
            int times = 1;
            Directory.CreateDirectory(destination);
            foreach (var item in dict)
            {
               // Console.WriteLine(@"{0} : {1}", item.Key, item.Value);
                string path =destination+ Path.GetFileName(item.Key) + ".bak1";



                //try
                //{
                if (File.Exists(path))
                {
                    if (!dict2.ContainsKey(item.Key)) { 
                    dict2.Add(item.Key, 1);
                    }
                    dict2[item.Key]++;
                    times = dict2[item.Key];

                        string name = destination + Path.GetFileName(item.Key) + ".bak" + times;
                    while( File.Exists(name))
                    {
                        times++;
                        name = destination + Path.GetFileName(item.Key) + ".bak" + times;
                      
                    }
                    Console.WriteLine("Copy, {0}", name);
                    //File.Copy(item.Key, name);
                    Compress(item.Key, name);
                }
                    else
                    {

                    //File.Copy(item.Key, path);
                    Compress(item.Key, path);
                        dict2.Add(item.Key, 1);
                 
                    }
                //}
                //catch
                //{
                //    if ()
                //}
              
            }

        }
        static Dictionary<string, DateTime> validation(ref Dictionary<string, DateTime> olddict)
        {
             Dictionary<string, DateTime> newdict = new Dictionary<string, DateTime> { };
            showAllFiles(dir, ref newdict);
            return olddict.Where(kvp => newdict[kvp.Key] != kvp.Value)
     .ToDictionary(kvp => kvp.Key, kvp => newdict[kvp.Key]);
        }



        static bool firstStart = false;
        static Dictionary<string, DateTime> dict = new Dictionary<string, DateTime> { };
        private static void Timer_scenario(object sender, ElapsedEventArgs e)
        {
            Dictionary<string, DateTime> newdict = new Dictionary<string, DateTime> { };
            Dictionary<string, int> times = new Dictionary<string, int> { };
            Dictionary<string, DateTime> tempdict= new Dictionary<string, DateTime> { };
            if (n < 10000)
            {
                // показать время срабатывания таймера
               
           
                showAllFiles(dir, ref dict);

                foreach (var item in dict)
                {
                    //Console.WriteLine(@"{0} : {1}", item.Key, item.Value);
                }

                //
                if (firstStart == false)
                {
                    CopyFromDictionary(dir2, ref dict, ref times);
                    Console.WriteLine("work if");
                    firstStart = true;
                }
                foreach (var item in times)
                {
                    // Console.WriteLine(@"{0} : {1}", item.Key, item.Value);
                }
                newdict = validation(ref dict);
                foreach (var item in newdict)
                {
                    Console.WriteLine(@"{0} : {1}", item.Key, item.Value);
                }
                CopyFromDictionary(dir2, ref newdict, ref times);
                foreach (var item in newdict)
                {
                    dict[item.Key] = item.Value;
                }
                Console.WriteLine(@"Clear");
                newdict.Clear();
                showAllFiles(dir, ref newdict);
        
                foreach (var items in newdict)
                {
                    if (!dict.ContainsKey(items.Key))
                    {
                        Console.WriteLine(items.Key);
                        Console.WriteLine(items.Value);
                        //dict[item.Key] = item.Value;
                        if (!dict.ContainsKey(items.Key))
                        {
                            dict.Add(items.Key, items.Value);
                        }
                        //newdict.Remove(items.Key);
                        //break;
                    }

                }
                newdict.Clear();
                Console.WriteLine("Timer tick: {0}, n = {1}", e.SignalTime.ToString(), n);
                n++;
            }
            else
            {
                // остановка таймера
                ((System.Timers.Timer)sender).Stop();
            }
        }
        static System.Timers.Timer timer;
        static int n = 0;
        static void Main(string[] args)
        {
           

            timer = new System.Timers.Timer(2000);

            // интервал срабатывания таймера
            timer.Interval = 1000;

            // указать метод, который будет запускаться по таймеру

            timer.Elapsed += Timer_scenario;

            // запуск таймера
            timer.Start();

            //for (int i = 0; i < 100; i++)
            //{
            //    Console.WriteLine($"i = {i}");
            //    Thread.Sleep(150);
            //}

            Console.WriteLine("Press any key for exit.");
            Console.ReadKey();
        }
    }
}
