﻿//2.Разработать свой механизм сериализации, который позволяет сериализовать и десериализовать экземпляр пользоватьского
//класса в файл определённого, заданного сериализатором формата. Атрибуты показывают свойства, которые нужно сериализовать.
//Ограничение на типы полей: Int32, String, Double

using System;
using System.IO;
using System.Reflection;

namespace USerializerClass
{
    class Store : Attribute { }

    //[Serializable]
    class Person
    {
        [Store]
        public int age;

        [Store]
        public double height;

        public int salary;

        [Store]
        public string name;

        [Store]
        public string lastname;

        public Person()
        {
            this.name = "none";
            this.lastname = "none";
        }

        public Person(string name, string lastname, int age, double height, int salary) 
        {
            this.name = name;
            this.lastname = lastname;
            this.age = age;
            this.height = height;
            this.salary = salary;
        }

        public int Age 
        {
            get { return age; }
            set { age = value; }
        }

        public double Height
        {
            get { return height; }
            set { height = value; }
        }

        public int Salary
        {
            get { return salary; }
            set { salary = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Cериализация объекта
            Person person = new Person("John", "Smith", 27, 180.6, 12000);

            MySerializer serializer = new MySerializer();
            FileStream file_in = new FileStream("person.dat", FileMode.Create, FileAccess.Write, FileShare.None);
            serializer.Serialize(file_in, person);
            file_in.Close();

            // Десериализация объекта
            FileStream file_out = File.OpenRead("person.dat");
            Person person2 = (Person)serializer.Deserialize(file_out);
            file_out.Close();
        }
    }

    internal class MySerializer
    {
        public void Serialize(FileStream save, Person person) 
        {
            // Получить информацию об объекте
            Type objtype = person.GetType();

            // Получить список полей объекта
            FieldInfo[] fields = objtype.GetFields();

            // Перебрать список полей
            foreach (FieldInfo field in fields)
            {
                // Если есть атрибут OpenField
                Attribute storeFieldAttr = field.GetCustomAttribute(typeof(Store));
                if (storeFieldAttr != null)
                {
                    // Записываем в файл
                    byte[] array = System.Text.Encoding.Default.GetBytes($"{field.Name} {field.GetValue(person)}\n");
                    save.Write(array, 0, array.Length);
                }
            }
        }

        public object Deserialize(FileStream source) 
        {
            Person person = new Person();
            // Получить информацию об объекте
            Type objtype = person.GetType();

            // Получить список полей объекта
            FieldInfo[] fields = objtype.GetFields();

            // преобразуем строку в байты
            byte[] array = new byte[source.Length];
            // считываем данные
            source.Read(array, 0, array.Length);
            // декодируем байты в строку
            string text = System.Text.Encoding.Default.GetString(array);
            string[] strs = text.Split("\n");
            Console.WriteLine("Load:");
            Console.WriteLine(text);

            // Перебрать список полей
            foreach (FieldInfo field in fields)
            {
                // Если есть атрибут OpenField
                Attribute openFieldAttr = field.GetCustomAttribute(typeof(Store));
                if (openFieldAttr != null)
                {
                    for (int i = 0; i < strs.Length; i++)
                    {
                        // Проверка имен полей
                        if (field.Name == "age" && strs[i].Split()[0] == "age")
                        {
                            field.SetValue(person, Convert.ToInt32(strs[i].Split()[1]));
                        }

                        if (field.Name == "height" && strs[i].Split()[0] == "height")
                        {
                            field.SetValue(person, Convert.ToDouble(strs[i].Split()[1]));
                        }

                        if (field.Name == "name" && strs[i].Split()[0] == "name")
                        {
                            field.SetValue(person, strs[i].Split()[1]);
                        }

                        if (field.Name == "lastname" && strs[i].Split()[0] == "lastname")
                        {
                            field.SetValue(person, strs[i].Split()[1]);
                        }
                    }
                }
            }
            return person;
        }
    }
}
