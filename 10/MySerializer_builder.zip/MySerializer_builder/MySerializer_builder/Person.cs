﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySerializer_builder
{
    class Store : Attribute { }
    class Person
    {
        //[Store]
        public int age;
        [Store]
        public double w;
        public void Print()
        {
            Console.WriteLine("From Person");
            Console.WriteLine(age);
            Console.WriteLine(w);
            Console.WriteLine();
        }
    }
}
