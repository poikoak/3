﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.IO;

namespace MySerializer_builder
{
    class Serializer
    {
        protected List<string> b = new List<string>();
        
        public void ReadClassInBuffer(ITypeSerialization type, Object o, string attributename = null)
        {

            type.ReadClassInBuffer(o, attributename);
           
            b = type.GetResult();            
            

        }
        public void SerealizeClassToFile(ITypeSerialization type, FileStream filename)
        {
            type.SaveClassToFile(filename);
        }
        public object Deserialize(ITypeSerialization type, FileStream file)
        {
            type.LoadFromFile(file);
            return type.GetResultObj();
        }
        public void Print(ITypeSerialization type)
        {
            type.Print();
        }
        public void ClearBuff(ITypeSerialization type)
        {
            type.Clear();
            if (b != null)
            {
                b.Clear();
            }
        }
        
    }
    interface ITypeSerialization
    {
        void ReadClassInBuffer(Object o, string attributename);
        void SaveClassToFile(FileStream filename);
        void LoadFromFile(FileStream filename);
        void Print();
        void Clear();
        List<string> GetResult();
        Object GetResultObj();
    }
    class WithAttribute : ITypeSerialization
    {
        protected List<string> b = new List<string>();
        protected Object o = new Object();
        public void ReadClassInBuffer(Object o, string attributename)
        {
            Type t = o.GetType();
            b.Add(Convert.ToString(o.GetType()));

            FieldInfo[] fi = t.GetFields();
           
            foreach (var item in fi)
            {
                IEnumerable<System.Attribute> a =  item.GetCustomAttributes();
                foreach (var item1 in a)
                {
                    if (item1.ToString().Contains(attributename))
                    {
                        b.Add(Convert.ToString(item.GetValue(o)));
                    }
                }             
               
            }
        }
        public List<string> GetResult()
        {
           
            return b;
        }
        public void Print()
        {
            Console.WriteLine("WithAttribute");
            foreach (var item in b)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        }

        public void SaveClassToFile(FileStream filename)
        {
            foreach (var item in b)
            {
                byte[] bytes = Encoding.UTF8.GetBytes(item + "\n");
                filename.Write(bytes, 0, bytes.Length);
            }
            //b.Clear();
           
        }

        public void LoadFromFile(FileStream filename)
        {
            StreamReader s = new StreamReader(filename.Name);
            string str = s.ReadToEnd();
            string[] sp = str.Split();

            Type t = Type.GetType(sp[0]);
            Object obj = Activator.CreateInstance(t);
            FieldInfo[] fields = t.GetFields();
            int counter = 1;
            foreach (var item in fields)
            {
                Attribute openFieldAttr = item.GetCustomAttribute(typeof(Store));
                if (openFieldAttr != null)
                {
                    for (int i = counter; i < sp.Length;)
                    {
                        item.SetValue(obj, Convert.ChangeType(sp[i], item.FieldType));
                        counter++;
                        break;
                    }
                }
            }
            o = obj;
        }

        public object GetResultObj()
        {
           return o;
        }

        public void Clear()
        {
            if (b != null)
            {
                b.Clear();
            };
        }
    }
    class WithoutAttribute: ITypeSerialization
    {
        protected List<string> b = new List<string>();
        protected Object o = new Object();
        public void ReadClassInBuffer(Object o, string param = null)
        {
            Type t = o.GetType();
            b.Add(Convert.ToString(o.GetType()));

            FieldInfo[] fi = t.GetFields();

            foreach (var item in fi)
            {
               
             b.Add(Convert.ToString(item.GetValue(o)));
                
            }
        }
        public List<string> GetResult()
        {            
            return b;
        }
        public void Print()
        {
            Console.WriteLine("WithoutAttribute");
            foreach (var item in b)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        }
              
        public void SaveClassToFile(FileStream filename)
        {
            foreach (var item in b)
            {
                byte[] bytes = Encoding.UTF8.GetBytes(item + "\n");
                filename.Write(bytes, 0, bytes.Length);
            }
            //b.Clear();
        }

        public void LoadFromFile(FileStream filename)
        {
            StreamReader s = new StreamReader(filename.Name);
            string str = s.ReadToEnd();
            string[] sp = str.Split();

            Type t = Type.GetType(sp[0]);
            Object obj = Activator.CreateInstance(t);
            FieldInfo[] fields = t.GetFields();
            int counter = 1;
            foreach (var item in fields)
            {                
               for (int i = counter; i < sp.Length;)
                {
                  item.SetValue(obj, Convert.ChangeType(sp[i], item.FieldType));
                  counter++;
                  break;
                }
                
            }
            o = obj;
        }

        public object GetResultObj()
        {
            return o;
        }

        public void Clear()
        {
            if (b!=null)
            {
                b.Clear();
            };
        }
    }
}
