﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MySerializer_builder
{
    class Program
    {       
                
        static void Main(string[] args)
        {
            Person test = new Person{ age = 12, w = 4.5 };
            Serializer m = new Serializer();
            ITypeSerialization b = new WithAttribute();
            ITypeSerialization b1 = new WithoutAttribute();
            FileStream fs = new FileStream("Test.txt", FileMode.Create, FileAccess.Write);
            FileStream fs1 = new FileStream("Test1.txt", FileMode.Create, FileAccess.Write);
            
            m.ReadClassInBuffer(b,  test, "Store");
            m.ReadClassInBuffer(b1, test);
            
            m.SerealizeClassToFile(b, fs);
            fs.Close();
            m.SerealizeClassToFile(b1, fs1);
            fs1.Close();

            FileStream f2 = File.OpenRead("Test.txt");
            Person test1 = (Person)m.Deserialize(b, f2);
            test1.Print();

            FileStream f3 = File.OpenRead("Test1.txt");
            Person test2 = (Person)m.Deserialize(b1, f3);
            test2.Print();

            m.Print(b1);
            m.Print(b);


            m.ClearBuff(b1);
            m.ClearBuff(b);


            Student s = new Student { n = "Nane" };
            m.ReadClassInBuffer(b1, s);           
            m.Print(b1);

            FileStream fsnew = new FileStream("Test11.txt", FileMode.Create, FileAccess.Write);
            m.SerealizeClassToFile(b1, fsnew);
            fsnew.Close();

            FileStream f33 = File.OpenRead("Test11.txt");
            Student s1 = (Student)m.Deserialize(b1, f33);
            s1.Print();

          

        }
    }
}
