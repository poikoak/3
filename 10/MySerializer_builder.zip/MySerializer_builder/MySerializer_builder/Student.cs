﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySerializer_builder
{
    class Student
    {
        public string n;
        public Student() { }
        public void Print()
        {
            Console.WriteLine(n);
        }
    }
    
}
